<html>
<body>

<p>
Heading: Earn rewards by contributing to open-source software.
Subtext: pick a backlog item and upload your code. If your solution receives enough votes, ,you will receive rewards.
Or you can also review and vote on other developers contributions to receive rewards.
Heading: Become a part of a decentralised organisation
Subtext: contribute to the platform, earn rewards and you will receive voting rights and shares of future profits.
Welcome, testers to the Commenticode platform. This is an experiment in decentralised organisations and we could really use your opinion about the idea and the platform, as well as your input about what may be changed and improved.

Note: this application is in a testing phase and the coin rewards currently do not have any value.

</p>
<?php












?>
</body>
</html>